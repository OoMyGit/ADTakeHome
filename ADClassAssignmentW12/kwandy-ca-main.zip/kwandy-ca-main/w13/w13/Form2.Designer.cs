﻿namespace w13
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.comboaddnat = new System.Windows.Forms.ComboBox();
            this.comboaddteam = new System.Windows.Forms.ComboBox();
            this.tbname = new System.Windows.Forms.TextBox();
            this.tbnum = new System.Windows.Forms.TextBox();
            this.tbpos = new System.Windows.Forms.TextBox();
            this.tbheight = new System.Windows.Forms.TextBox();
            this.tbweight = new System.Windows.Forms.TextBox();
            this.buttonadd = new System.Windows.Forms.Button();
            this.date1 = new System.Windows.Forms.DateTimePicker();
            this.combo1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Player";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Add Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Add Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Add Nationality";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Add Position";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Add Weight";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Add Height";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Add Birthdate";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 273);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Add Team";
            // 
            // comboaddnat
            // 
            this.comboaddnat.FormattingEnabled = true;
            this.comboaddnat.Location = new System.Drawing.Point(127, 119);
            this.comboaddnat.Name = "comboaddnat";
            this.comboaddnat.Size = new System.Drawing.Size(121, 21);
            this.comboaddnat.TabIndex = 8;
            // 
            // comboaddteam
            // 
            this.comboaddteam.FormattingEnabled = true;
            this.comboaddteam.Location = new System.Drawing.Point(127, 273);
            this.comboaddteam.Name = "comboaddteam";
            this.comboaddteam.Size = new System.Drawing.Size(121, 21);
            this.comboaddteam.TabIndex = 9;
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(127, 46);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(100, 20);
            this.tbname.TabIndex = 10;
            // 
            // tbnum
            // 
            this.tbnum.Location = new System.Drawing.Point(127, 84);
            this.tbnum.Name = "tbnum";
            this.tbnum.Size = new System.Drawing.Size(100, 20);
            this.tbnum.TabIndex = 11;
            // 
            // tbpos
            // 
            this.tbpos.Location = new System.Drawing.Point(127, 151);
            this.tbpos.Name = "tbpos";
            this.tbpos.Size = new System.Drawing.Size(100, 20);
            this.tbpos.TabIndex = 12;
            // 
            // tbheight
            // 
            this.tbheight.Location = new System.Drawing.Point(127, 181);
            this.tbheight.Name = "tbheight";
            this.tbheight.Size = new System.Drawing.Size(100, 20);
            this.tbheight.TabIndex = 13;
            // 
            // tbweight
            // 
            this.tbweight.Location = new System.Drawing.Point(127, 210);
            this.tbweight.Name = "tbweight";
            this.tbweight.Size = new System.Drawing.Size(100, 20);
            this.tbweight.TabIndex = 14;
            // 
            // buttonadd
            // 
            this.buttonadd.Location = new System.Drawing.Point(25, 321);
            this.buttonadd.Name = "buttonadd";
            this.buttonadd.Size = new System.Drawing.Size(152, 84);
            this.buttonadd.TabIndex = 16;
            this.buttonadd.Text = "Add";
            this.buttonadd.UseVisualStyleBackColor = true;
            this.buttonadd.Click += new System.EventHandler(this.buttonadd_Click);
            // 
            // date1
            // 
            this.date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date1.Location = new System.Drawing.Point(127, 241);
            this.date1.Name = "date1";
            this.date1.Size = new System.Drawing.Size(121, 20);
            this.date1.TabIndex = 17;
            // 
            // combo1
            // 
            this.combo1.FormattingEnabled = true;
            this.combo1.Location = new System.Drawing.Point(127, 10);
            this.combo1.Name = "combo1";
            this.combo1.Size = new System.Drawing.Size(121, 21);
            this.combo1.TabIndex = 18;
            this.combo1.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.combo1);
            this.Controls.Add(this.date1);
            this.Controls.Add(this.buttonadd);
            this.Controls.Add(this.tbweight);
            this.Controls.Add(this.tbheight);
            this.Controls.Add(this.tbpos);
            this.Controls.Add(this.tbnum);
            this.Controls.Add(this.tbname);
            this.Controls.Add(this.comboaddteam);
            this.Controls.Add(this.comboaddnat);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboaddnat;
        private System.Windows.Forms.ComboBox comboaddteam;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.TextBox tbnum;
        private System.Windows.Forms.TextBox tbpos;
        private System.Windows.Forms.TextBox tbheight;
        private System.Windows.Forms.TextBox tbweight;
        private System.Windows.Forms.Button buttonadd;
        private System.Windows.Forms.DateTimePicker date1;
        private System.Windows.Forms.ComboBox combo1;
    }
}